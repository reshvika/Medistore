package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    public static Connection getConnection() throws Exception {
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/med", // DB name is 'med'
                "root",                            // your MySQL username
                "tiger"                     // your MySQL password (replace this!)
            );
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Database connection failed.");
        }
    }
}
