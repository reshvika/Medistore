package dao;

import model.Medicine;
import util.DB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicineDAO {

    // Make this method static
	public static boolean addMedicine(Medicine med) {
	    try (Connection con = DB.getConnection()) {
	        String sql = "INSERT INTO medicines (name, description, price, quantity) VALUES (?, ?, ?, ?)";
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setString(1, med.getName());
	        ps.setString(2, med.getDescription());
	        ps.setDouble(3, med.getPrice());
	        ps.setInt(4, med.getQuantity());
	        return ps.executeUpdate() > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}


    // Fetch all medicines from the database
    public static List<Medicine> getMedicines() {
        List<Medicine> medicines = new ArrayList<>();
        try (Connection con = DB.getConnection()) {
            String sql = "SELECT * FROM medicines";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Medicine medicine = new Medicine();
                medicine.setId(rs.getInt("id"));
                medicine.setName(rs.getString("name"));
                medicine.setDescription(rs.getString("description"));
                medicine.setPrice(rs.getDouble("price"));
                medicine.setQuantity(rs.getInt("quantity"));
                medicines.add(medicine);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return medicines;
    }

    // Delete a medicine by ID
    public static boolean deleteMedicine(int id) {
        try (Connection con = DB.getConnection()) {
            String sql = "DELETE FROM medicines WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

