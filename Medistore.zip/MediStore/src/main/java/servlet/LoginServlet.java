package servlet;

import dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle POST request for login
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Authenticate user using DAO
        boolean isLoggedIn = UserDAO.login(email, password);

        if (isLoggedIn) {
            // Start session and redirect to shop page
            HttpSession session = request.getSession();
            session.setAttribute("userEmail", email);
            response.sendRedirect("shop.html");
        } else {
            // If login fails, display message
            response.getWriter().println("Login failed. <a href='login.html'>Try again</a>");
        }
    }
}
