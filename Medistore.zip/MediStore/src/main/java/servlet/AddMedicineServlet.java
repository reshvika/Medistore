package servlet;

import model.Medicine;
import dao.MedicineDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/addMedicine")
public class AddMedicineServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Medicine medicine = new Medicine(0, name, description, price, quantity);

        // Calling the static method to add the medicine
        boolean result = MedicineDAO.addMedicine(medicine);

        if (result) {
            response.getWriter().write("Medicine " + name + " added successfully!");
        } else {
            response.getWriter().write("Error adding medicine.");
        }
    }
}
